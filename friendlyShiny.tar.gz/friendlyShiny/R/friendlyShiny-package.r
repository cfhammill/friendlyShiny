#' friendlyShiny.
#'
#' @name friendlyShiny
#' @docType package
NULL
